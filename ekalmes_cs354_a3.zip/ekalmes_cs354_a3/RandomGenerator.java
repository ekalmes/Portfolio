/**
* RandomGenerator is a class containing a method called ArrayGenerator. 
* <p>
* This is an extension of the first assignment (assignment 1.5) in Prof. Liffiton's CS 354 class at IWU.
* </p>
* @author	Ezekial Kalmes
* @version	1.0, 19 Jan 2022
* @see		LinearBinaryRandom.java
* @see 		<code>java.util.Arrays</code>
* @see 		<code>java.util.Random</code>
*/

import java.util.Random;
import java.util.Arrays;
public class RandomGenerator {
    
    /** 
     * This method creates a randomly generated integer array of a given size. 
     * <p>
     * It then sorts the created array for passing it to different search algorithms. 
     * </p>
     * @param ArraySize the desired size in memory for the array that is to be created
     * @return int[]
     * @see      <code>java.util.Random</code>
     * @see      <code>java.util.Arrays</code>
     */
    public static int[] ArrayGenerator(int ArraySize) {
        Random rand = new Random(); // creating Random object
        int[] arr = new int[ArraySize]; // creating array of the size given in argument ArraySize
        for (int i = 0; i < arr.length; i++) {
           arr[i] = rand.nextInt(ArraySize); 
        }
        // use sort method of java.util.Arrays class to sort the randomly generated integer array
        Arrays.sort(arr);
        return arr;
    }


	public static int[] partiallySortedArray(int ArraySize) {
		Random rand = new Random();
        int[] arr = new int[ArraySize]; // creating array of the size given in argument ArraySize
        for (int i = 0; i < arr.length; i++) {
        	if (arr[i]%2 == 0) {
        		arr[i] = i;
        	}
        	else {
        		arr[i] = rand.nextInt(ArraySize+1); 
        	}
        }
        return arr;
	}
}