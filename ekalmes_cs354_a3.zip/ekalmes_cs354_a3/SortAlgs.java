/**
 * A class containing a main method that acts as a driver for the HybridSort Class.
 * 
 * @author Zeke Kalmes
 * Date: 2022-02-16
*/
public class SortAlgs {
	/**
	 * Takes in command line arguments, calls hybridsort,
	 * and prints resulting sorted array with each element on its own line. 
	 * @param args
	 */
	public static void main(String[] args) {
		// read arguments from command line
		int threshold = Integer.parseInt(args[0]);
		float split = Float.parseFloat(args[1]);
		
		// use StdIn to read integers from .txt file
		int list[] = StdIn.readAllInts();
		
		int results[] = HybridSort.hybridsort(list, threshold, split);
		
		for (int i = 0; i<results.length; i++) {
			System.out.println(results[i]);
		}
	}
}