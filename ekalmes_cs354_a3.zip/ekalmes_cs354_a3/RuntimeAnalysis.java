import java.util.Random;
import java.util.Collections;
import java.util.Arrays;
import java.lang.Math;
public class RuntimeAnalysis {

	public static void main(String[] args) {
        Random rnd = new Random();
        String testType = args[0];
        // should be 3 to start logging at array size of 8, but afraid it will mess up parsing of runtime array as it gets set to i.
        // ignoring 1,2,4 in {search type}output.txt
        int minPower = 0;
        int maxPower = 20;
        int numIterations = 10; 
        // conditionals for choosing which search type to analyze
        if (testType.equals("split")) {
        	// prints format/column names for {search type}output.txt
            System.out.println("split" + "," + "n" + "," + "min" + "," + "avg" + "," + "max");
        	float split[] = { (float)0.01, (float)0.1, (float)0.25, (float)0.5, (float)0.75, (float)0.9, (float)0.99 };
        	// must not be primitive long type so Collections.min/.max will work
            Long[][][] runtime = new Long[split.length][maxPower-minPower][numIterations];
            for (int m = 0; m < split.length; m++) {
            	float splitSize = split[m];
            	// for loop to generate partially-sorted arrays of increasing size
	            for (int i = minPower; i < maxPower; i++) {
	                // have to do some manipulating of datatypes to make Math.pow happy (params must be doubles)
	                double d = i;
	                double ArraySizeDouble = Math.pow(2, d);
	                // turn ArraySize back into int using TypeCasting, so able to pass it to rnd.nextInt() as well as RandomGenerator.
	                int ArraySize = (int)ArraySizeDouble;
	                int[] arr = RandomGenerator.partiallySortedArray(ArraySize);
	                // resets row total every change in array size
	                long rowTotal = 0;
	                // nested for loop to run numIterations of runtime analysis at each size of array. 
	                for (int x = 0; x < numIterations; x++) {
	                    Long startTime = System.nanoTime();
	                    HybridSort.hybridsort(arr, 0, splitSize);
	                    Long elapsedTime = System.nanoTime() - startTime;
	                    //stores elapsed time of iteration in current 
	                    runtime[m][i][x]=elapsedTime;
	                    rowTotal += runtime[m][i][x];
	                }
            
	            System.out.println(split[m] + "," + ArraySize + "," + Collections.min(Arrays.asList(runtime[m][i])) + "," + (rowTotal / numIterations) + "," + Collections.max(Arrays.asList(runtime[m][i])));
            }
            }
        }
        else {
        	// prints format/column names for {search type}output.txt
            System.out.println("threshold" + "," + "n" + "," + "min" + "," + "avg" + "," + "max");
        	int[] threshold = { 0, 4, 16, 64, 1024, (int)Math.pow(2, 30) };
        	// must not be primitive long type so Collections.min/.max will work
            Long[][][] runtime = new Long[threshold.length][maxPower-minPower][numIterations];
            for (int m = 0; m < threshold.length; m++) {
            	int threshSize = threshold[m];
            	// for loop to generate partially-sorted arrays of increasing size
	            for (int i = minPower; i < maxPower; i++) {
	                // have to do some manipulating of datatypes to make Math.pow happy (params must be doubles)
	                double d = i;
	                double ArraySizeDouble = Math.pow(2, d);
	                // turn ArraySize back into int using TypeCasting, so able to pass it to rnd.nextInt() as well as RandomGenerator.
	                int ArraySize = (int)ArraySizeDouble;
	                int[] arr = RandomGenerator.partiallySortedArray(ArraySize);
	                // resets row total every change in array size
	                long rowTotal = 0;
	                // nested for loop to run numIterations of runtime analysis at each size of array. 
	                for (int x = 0; x < numIterations; x++) {
	                    Long startTime = System.nanoTime();
	                    HybridSort.hybridsort(arr, threshSize, (float)0.5);
	                    Long elapsedTime = System.nanoTime() - startTime;
	                    //stores elapsed time of iteration in current 
	                    runtime[m][i][x]=elapsedTime;
	                    rowTotal += runtime[m][i][x];
	                }
            
	            System.out.println(threshold[m] + "," + ArraySize + "," + Collections.min(Arrays.asList(runtime[m][i])) + "," + (rowTotal / numIterations) + "," + Collections.max(Arrays.asList(runtime[m][i])));
            }
            }
		}
    }
}