/**
* A class containing an implementation of a HybridSort algorithm based on the MergeSort algorithm
 * operating on integer arrays. Utilizes threshold and split parameters
 * on the subarrays created by recursive calls to MergeSort to determine
 * if MergeSort or InsertionSort should be used from that point on, as well  
 * as determining the fraction of the list go to each subproblem.
 * 
 *
 * @author Zeke Kalmes
 * @author Mark Liffiton
 * Date: 2022-02-16
 */

import java.util.Arrays;

public class HybridSort {
	
	/**
	 * Performs HybridSort based on input parameters
	 * 
	 * @param list 
	 * @param threshold
	 * @param split
	 * @return a sorted copy of the input array
	 * @see #hybridsort_helper(int[], int, int, int, float)
	 */
	public static int[] hybridsort(int[] list, int threshold, float split) {
        return hybridsort_helper(list, 0, list.length-1, threshold, split);
    }
    
	/**
	 * A recursive helper function for {@link #hybridsort(int[], int, float)}. 
	 * Performs recursion until the threshold size, and then performs iterative
	 * {@link #insertionsort(int[])}. Allows hybridsort to have a cleaner interface.
	 * 
	 * @param list
	 * @param start
	 * @param end
	 * @param threshold
	 * @param split
	 * @return a sorted copy of list from index start to end (inclusive)
	 * @see #merge(int[], int[])
	 * @see #insertionsort(int[])
	 */
    private static int[] hybridsort_helper(int[] list, int start, int end, int threshold, float split) {
    	if (end == start) {
            // return a new array containing the one value
            int[] ret = { list[start] };
            return ret;
        }
		if ((end - start) <= threshold) {
			int[] insarray = Arrays.copyOfRange(list, start, end+1);
			return insertionsort(insarray);
		}
        else {	
        	// recursively sort two halves of the list
	        float fsplitpoint = start + ((end-start) * split);
	        int splitpoint = (int)fsplitpoint;
	        int[] left = hybridsort_helper(list, start, splitpoint, threshold, split);
	        int[] right = hybridsort_helper(list, splitpoint+1, end, threshold, split);
	
	        // merge the two sorted sublists
	        return merge(left, right);
	    }    
    }
    
    /**
     * Implementation of the standard InsertionSort Algorithm
     * @param arr
     * @return sorted integer array 
     */
	private static int[] insertionsort(int arr[]) {
		int n = arr.length;
        for (int i = 1; i < n; ++i) {
            int key = arr[i];
            int j = i - 1;
 
            /* Move elements of arr[0..i-1], that are
               greater than key, to one position ahead
               of their current position */
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
		return arr;
	}
	/**
     * Merges two sorted lists of integers into one new sorted list.
     * Both lists must be sorted for this method to function correctly.
     * Adapted from Prof. Liffiton's MergeSort Implementation.
     *
     * @param  l1  a sorted array of integers
     * @param  l2  another sorted array of integers
     * @return     the result of merging l1 and l2
     */
	private static int[] merge(int[] l1, int[] l2) {
        int[] merged = new int[l1.length + l2.length];

        // maintain pointers into the two inputs lists and the output list
        int ptr1=0, ptr2=0, ptrout=0;

        // as long as we haven't reached the end of either list
        while (ptr1 < l1.length && ptr2 < l2.length) {
            // place the smaller of the two pointed-to values (or the second
            // one, if they're equal) into the merged output, advancing
            // pointers with ++ as necessary.
            if (l1[ptr1] < l2[ptr2]) {
                merged[ptrout++] = l1[ptr1++];
            }
            else {
                merged[ptrout++] = l2[ptr2++];
            }
        }
        // copy the rest of l1 into merged, if any remains
        while (ptr1 < l1.length) {
            merged[ptrout++] = l1[ptr1++];
        }
        // copy the rest of l2 into merged, if any remains
        while (ptr2 < l2.length) {
            merged[ptrout++] = l2[ptr2++];
        }

        return merged;
    }

}




