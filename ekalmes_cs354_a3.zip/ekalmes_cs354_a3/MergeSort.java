/**
 * A class containing an implementation of the MergeSort algorithm
 * operating on integer arrays.
 *
 * The <code>main</code> method runs a series of randomized tests.
 *
 * @author Mark Liffiton
 * Date: 2018-01-31
 */

import java.util.Arrays;
import java.util.Random;

public class MergeSort {
    /**
     * Sorts an integer array using the MergeSort algorithm.
     *
     * @param  list  the array to be sorted
     * @return       a sorted copy of the input array
     * @see    #mergesort_helper
     */
    public static int[] mergesort(int[] list) {
        return mergesort_helper(list, 0, list.length-1);
    }

    /**
     * A recursive helper function for the #mergesort method.
     * By defining this helper, the #mergesort method can have
     * a cleaner interface without needing to specify a start and end
     * position when calling it on an entire array.
     *
     * @param  list  the list (an array of integers) to sort
     * @param start  the first index of the section of <code>list</code>
     *               to be sorted in this particular call
     * @param   end  the last index of the section to be sorted
     * @return       a sorted copy of list from index start to end (inclusive)
     */
    private static int[] mergesort_helper(int[] list, int start, int end) {
        if (end == start) {
            // return a new array containing the one value
            int[] ret = { list[start] };
            return ret;
        }

        // recursively sort two halves of the list
        int midpoint = start + (end-start) / 2;
        int[] left = mergesort_helper(list, start, midpoint);
        int[] right = mergesort_helper(list, midpoint+1, end);

        // merge the two sorted sublists
        return merge(left, right);
    }

    /**
     * Merges two sorted lists of integers into one new sorted list.
     * Both lists must be sorted for this method to function correctly.
     *
     * @param  l1  a sorted array of integers
     * @param  l2  another sorted array of integers
     * @return     the result of merging l1 and l2
     */
    private static int[] merge(int[] l1, int[] l2) {
        int[] merged = new int[l1.length + l2.length];

        // maintain pointers into the two inputs lists and the output list
        int ptr1=0, ptr2=0, ptrout=0;

        // as long as we haven't reached the end of either list
        while (ptr1 < l1.length && ptr2 < l2.length) {
            // place the smaller of the two pointed-to values (or the second
            // one, if they're equal) into the merged output, advancing
            // pointers with ++ as necessary.
            if (l1[ptr1] < l2[ptr2]) {
                merged[ptrout++] = l1[ptr1++];
            }
            else {
                merged[ptrout++] = l2[ptr2++];
            }
        }
        // copy the rest of l1 into merged, if any remains
        while (ptr1 < l1.length) {
            merged[ptrout++] = l1[ptr1++];
        }
        // copy the rest of l2 into merged, if any remains
        while (ptr2 < l2.length) {
            merged[ptrout++] = l2[ptr2++];
        }

        return merged;
    }

    /**
     * Returns whether an integer array is sorted or not.
     * This is an internal helper method for the tests in <code>main</code>.
     *
     * @param  list  the list to check
     * @return       true if the list is sorted in ascending order, else false
     */
    private static boolean isSorted(int[] list) {
        // test every sequential pair for correct ordering
        for (int i = 0 ; i < list.length - 1 ; i++) {
            if (list[i] > list[i+1]) {
                return false;
            }
        }
        return true;
    }

    /**
     * Returns whether two integer arrays contain the same values or not.
     * Requires that the first array parameter is sorted (it exploits this for
     * efficiency).
     * This is an internal helper method for the tests in <code>main</code>.
     *
     * @param  list1 the first list to compare (must be sorted)
     * @param  list2 the other list to compare
     * @return       true if the list is sorted in ascending order, else false
     */
    private static boolean isSameList(int[] list1, int[] list2) {
        for (int l2_val : list2) {
            if (Arrays.binarySearch(list1, l2_val) < 0) {
                // binarySearch() returns negative values if value is not found
                return false;
            }
        }
        return true;
    }

    /**
     * Runs a series of randomized tests to test correctness.
     * Generates and attempts to sort 2000 lists of sizes between 1 and 2^10+1
     * filled with random integers.  If any results are not sorted correctly,
     * the program will print an error.
     *
     * @see #isSorted
     * @see #isSameList
     */
    public static void main(String[] args) {
        Random rand = new Random();
        System.out.print("Running tests: ");

        int numtests = 2000;
        int failed = 0;
        
        int test1[] = {420, 69, 5, 8, 34, 2, 87, 54, 42};
        
        int result1[] = mergesort(test1);
        
        if (isSorted(result1) && isSameList(result1, test1)) {
            System.out.print(".");
        }
        else {
            System.out.print('x');
            failed++;
        }

//        for (int i = 0 ; i < numtests ; i++) {
//            // generate a list of random integers with length randomly chosen
//            // from the range 1 to 2^10+1
//            int len = 1 + rand.nextInt(1 << 10);
//            int[] test = new int[len];
//            for (int j = 0 ; j < len ; j++) {
//                test[j] = rand.nextInt();
//            }
//
//            // sort the list using the algorithm being tested
//            int[] result = mergesort(test);
//
//            // Check whether the result is sorted and contains the same
//            // values as the input list.
//            // Print one dot per successful test and one x per failed test as a
//            // simple progress meter.
//            if (isSorted(result) && isSameList(result, test)) {
//                System.out.print(".");
//            }
//            else {
//                System.out.print('x');
//                failed++;
//            }
//        }

        System.out.println();

        if (failed > 0) {
            System.out.println(failed + "/" + numtests + " tests failed.");
            System.exit(1);
        }
        else {
            System.out.println("All tests passed!");
        }
    }
}
